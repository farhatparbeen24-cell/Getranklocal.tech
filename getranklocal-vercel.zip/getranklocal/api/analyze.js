export default async function handler(req, res) {
  // Only allow POST
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { bizName, bizType, bizCity, bizAudience, bizUrl, bizDesc } = req.body;

  if (!bizName || !bizType) {
    return res.status(400).json({ error: 'Business name and type are required' });
  }

  const prompt = `You are an expert SEO and business growth consultant specializing in Indian markets. Analyze this business and return ONLY a valid JSON object (no markdown, no explanation):

Business Name: ${bizName}
Type: ${bizType}
Location: ${bizCity || 'India'}
Target Audience: ${bizAudience || 'General Indian consumers'}
Website: ${bizUrl || 'None'}
Description: ${bizDesc || 'No description provided'}

Return this exact JSON structure:
{
  "score": <number 0-100>,
  "scoreTitle": "<short verdict title>",
  "scoreDesc": "<2 sentence summary of current ranking health in Indian market>",
  "metrics": [
    {"val": "<value>", "label": "<label>"},
    {"val": "<value>", "label": "<label>"},
    {"val": "<value>", "label": "<label>"},
    {"val": "<value>", "label": "<label>"}
  ],
  "actions": [
    {"priority": "high", "icon": "<emoji>", "title": "<action title>", "desc": "<what to do and why, India-specific>"},
    {"priority": "high", "icon": "<emoji>", "title": "<action title>", "desc": "<what to do and why, India-specific>"},
    {"priority": "med", "icon": "<emoji>", "title": "<action title>", "desc": "<what to do and why>"},
    {"priority": "med", "icon": "<emoji>", "title": "<action title>", "desc": "<what to do and why>"},
    {"priority": "low", "icon": "<emoji>", "title": "<action title>", "desc": "<what to do and why>"}
  ],
  "keywords": [
    {"kw": "<India-relevant keyword>", "searches": "<est monthly India>", "diff": "Low|Medium|High", "opp": "<short opportunity note>"},
    {"kw": "<India-relevant keyword>", "searches": "<est monthly India>", "diff": "Low|Medium|High", "opp": "<short opportunity note>"},
    {"kw": "<India-relevant keyword>", "searches": "<est monthly India>", "diff": "Low|Medium|High", "opp": "<short opportunity note>"},
    {"kw": "<India-relevant keyword>", "searches": "<est monthly India>", "diff": "Low|Medium|High", "opp": "<short opportunity note>"},
    {"kw": "<India-relevant keyword>", "searches": "<est monthly India>", "diff": "Low|Medium|High", "opp": "<short opportunity note>"}
  ],
  "roadmap": [
    {"week": "Week 1-2", "title": "<phase title>", "desc": "<what to do>"},
    {"week": "Week 3-5", "title": "<phase title>", "desc": "<what to do>"},
    {"week": "Week 6-9", "title": "<phase title>", "desc": "<what to do>"},
    {"week": "Week 10-12", "title": "<phase title>", "desc": "<what to do>"}
  ]
}`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1500,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    if (!response.ok) {
      const err = await response.text();
      console.error('Anthropic error:', err);
      return res.status(500).json({ error: 'AI service error' });
    }

    const data = await response.json();
    const raw = data.content.map(b => b.text || '').join('');
    const clean = raw.replace(/```json|```/g, '').trim();
    const result = JSON.parse(clean);

    return res.status(200).json(result);

  } catch (err) {
    console.error('Handler error:', err);
    return res.status(500).json({ error: 'Analysis failed. Please try again.' });
  }
}
