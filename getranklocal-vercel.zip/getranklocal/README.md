# getranklocal.tech — Vercel Deployment Guide

## Project Structure
```
getranklocal/
├── api/
│   └── analyze.js       ← Secure backend (API key yahan rahegi)
├── public/
│   └── index.html       ← Frontend website
└── vercel.json          ← Vercel configuration
```

---

## Step-by-Step Deploy Karo

### Step 1 — GitHub pe upload karo
1. GitHub.com pe jaao → New Repository banao: `getranklocal`
2. Ye teeno files/folders upload karo (same structure mein)

### Step 2 — Vercel pe deploy karo
1. [vercel.com](https://vercel.com) pe jaao → Sign up (free)
2. "Add New Project" → GitHub repo select karo
3. Deploy button dabaao — automatically deploy ho jayega

### Step 3 — API Key add karo (IMPORTANT)
1. Vercel Dashboard → Your Project → **Settings** → **Environment Variables**
2. Add karo:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** `sk-ant-xxxxxxxxxxxxxxxxx` (apni real key)
   - **Environment:** Production + Preview + Development (teeno tick karo)
3. Save karo → **Redeploy** karo project ko

### Step 4 — Custom Domain connect karo
1. Vercel Dashboard → Project → **Settings** → **Domains**
2. Add: `getranklocal.tech`
3. Vercel tumhe 2 DNS records dega (A record + CNAME)
4. Apne domain registrar (GoDaddy/Namecheap etc.) mein ye DNS records add karo
5. 5-10 minute mein live ho jayega!

---

## Anthropic API Key kahan se milegi?
1. [console.anthropic.com](https://console.anthropic.com) pe jaao
2. Account banao → **API Keys** → **Create Key**
3. Key copy karo → Vercel mein paste karo (Step 3)

## Cost kitna aayega?
- Vercel: **FREE** (Hobby plan kaafi hai)
- Anthropic API: ~$0.003 per analysis (bahut sasta)
  - 1000 analyses/month = ~₹250 only

---

## AdSense Kaise Lagaayein?
`public/index.html` mein ye 3 jagah hain:
```html
<!-- Google AdSense Ad Unit Here -->
```
Inhe apne real AdSense code se replace karo.
